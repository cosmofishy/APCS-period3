import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.util.ArrayList;
import java.util.List;

import javax.swing.AbstractAction;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;
import javax.swing.Timer;
/**
 * Write a description of class gg here.
 * 

/* This is our class for keeping track of an individual ball
 * and it's position, movement and how it is drawn. */
class Ball {
    /* Let's say all balls will have the same diameter of 35.
     * The static modifier says that this is a value
     * that is shared by all instances of Ball. */ 
    static final int SIZE = 35;
    /* Let's say all balls will have a speed in both the X and Y
     * axes of 3. The static modifier says that this is a value
     * that is shared by all instances of Ball. */ 
    static final int SPEED = 3;
    /* Each ball needs to know its position, which we will store
     * as x and y coordinates in 2D space */
    int x, y; 
    /* Each ball needs to know the bounds in which it lives, so
     * it knows when to bounce. We'll be assuming the minimum
     * bound is 0,0 in 2D space. The maximum bound will be
     * maxX,mayY in 2D space. We could have made these static
     * and shared by all balls, but that means we would have
     * to remember to change them to not be static if in the
     * future we wanted Ball to be used on more than one JPanel.
     * If we didn't remember, then we'd see some buggy behaviour. */
    int maxX, maxY;
    /* Each ball needs to know its current speed in the X and Y 
     * directions. We can use positive and negative values to
     * keep track of the direction of the ball's movement. */
    int speedX = SPEED, speedY = SPEED;
    /* Each ball needs to know which panel it is being drawn to
     * (this is needed by ImageIcon#drawImage()). */
    JPanel panel;
    public Ball(JPanel panel, int x, int y, int maxX, int maxY) { 
        this.x = x; this.y = y;
        this.maxX = maxX; this.maxY = maxY;
        this.panel = panel;
    }
    public void setBounds(int maxX, int maxY) {
        this.maxX = maxX; this.maxY = maxY;
    }
    /* This method updates the position of this ball, using
     * the current speed and bounds to work out what the new
     * position should be.
     * This should be called by our BallPanel#actionPerformed()
     * method in response to the Timer we set up in the Rebound
     * class. */
    public void move() {
        x += speedX;
        y += speedY;
        // Approx bounce, okay for small speed
        if (x<0) { speedX=-speedX; x=0; }
        if (y<0) { speedY=-speedY; y=0; }
        if (x+SIZE>maxX) { speedX=-speedX; x=maxX-SIZE; }
        if (y+SIZE>maxY) { speedY=-speedY; y=maxY-SIZE; }
    }
    /* This method is responsible for drawing this ball on
     * the provided graphics context (which should come from
     * the JPanel associated with the ball). We also have
     * the panel, should we need it (ImageIcon#drawImage() needs 
     * this, but Graphics#drawOval() does not.)
     */
    public void draw(Graphics g) {
        //image.paintIcon(panel, g, x, y); - commented out because I don't have an ImageIcon
        g.drawOval(x, y, SIZE, SIZE);
    }
}