import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import javax.swing.JFrame;

public class mainFrame extends JFrame implements KeyListener{
    private mainDraw draw;
    private mainDraw1 draw1;
    public void keyPressed(KeyEvent e) {
        System.out.println("keyPressed");
    }

    public void keyReleased(KeyEvent e) {
        if(e.getKeyCode()== KeyEvent.VK_RIGHT)
            draw.moveRight();
        else if(e.getKeyCode()== KeyEvent.VK_LEFT)
            draw.moveLeft();
        else if(e.getKeyCode()== KeyEvent.VK_DOWN)
            draw.moveDown();
        else if(e.getKeyCode()== KeyEvent.VK_UP)
            draw.moveUp();

    }

    public void keyTyped(KeyEvent e) {
        System.out.println("keyTyped");
    }

    public mainFrame(){
        this.draw=new mainDraw();
        addKeyListener(this);
        setFocusable(true);
        setFocusTraversalKeysEnabled(false);
        //this.draw1=new mainDraw1();
        
    }

    public static void main(String[] args) {
        javax.swing.SwingUtilities.invokeLater(new Runnable() {
                public void run() {
                    mainFrame frame = new mainFrame();
                   
                    frame.setTitle("Square Move Practice");
                    frame.setSize(600, 600);
                    frame.setMinimumSize(new Dimension(600, 600));
                    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                    frame.getContentPane().add(frame.draw);
                    //frame.add(frame.draw1);
                    frame.setVisible(true);
                    frame.pack();
                    frame.pack();
                    frame.setVisible(true);
                    frame.add(new TrainCanvas());
                    frame.setVisible(true);
                    frame.add(new TrainCanvas());
                    frame.setVisible(true);
                    frame.add(new TrainCanvas());
                    frame.setVisible(true);
                    frame.add(new TrainCanvas());
                    frame.setVisible(true);

                }
            });
    }
}