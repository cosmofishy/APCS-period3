import java.awt.Color;
import java.awt.Graphics;
import javax.swing.JComponent;
import javax.swing.*;
import java.awt.*;
import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.event.*;
import javax.swing.*;
public class mainDraw extends JComponent {

    public int x = 50;
    public int y = 50;

    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        g.setColor(Color.RED);
        Graphics2D gg = (Graphics2D) g;
        g.drawRect(x, y, 50, 50);
        g.fillRect(x, y, 50, 50);
    }

    public void moveRight() {
        x = x + 25;
        repaint();
    }

    public void moveLeft() {
        x = x - 25;
        repaint();
    }

    public void moveDown() {
        y = y + 25;
        repaint();
    }

    public void moveUp() {
        y = y - 25;
        repaint();
    }

}