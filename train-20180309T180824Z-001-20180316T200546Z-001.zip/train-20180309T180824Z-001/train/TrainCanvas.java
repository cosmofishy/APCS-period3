import javax.swing.*;
import java.awt.*;
import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.event.*;
import javax.swing.*;
class TrainCanvas extends JComponent {
    private int lastX = 0;
    private int lastX1 = 0;
    private int lastX2 = 0;
    public TrainCanvas() {
        Thread animationThread = new Thread(new Runnable() {
                    public void run() {
                        while (true) {
                            repaint();
                            try {Thread.sleep(10);} catch (Exception ex) {}
                        }
                    }
                });
        animationThread.start();
    }

    /*public TrainCanvas(int w, int h, int trainW,int trainH, int trainSpeed, int x ) {

    int  w = getWidth();
    int h = getHeight();
    int  trainW = 100;
    int trainH = 10;
    int trainSpeed = 3;
    int  x = lastX + trainSpeed;

    TrainCanvas train1 = new TrainCanvas(100, 50, 100, 10, 6, x);
    TrainCanvas train2 = new TrainCanvas(100, 0, 100, 10, 6, x);
    }
     */
    public void paintComponent(Graphics g) {

        int  w = getWidth();
        int h = getHeight();
        int  trainW = 100;
        int trainH = 10;
        int trainSpeed = 3;
        int  x = lastX + trainSpeed;

        // Train train0=new Train(100, 50, 100, 10, 6, 9);

        Graphics2D gg = (Graphics2D) g;
        if (x > w + trainW) {
            x = -trainW;

        }
        gg.setColor(Color.BLACK);
        gg.fillRect(x, h/2 + trainH, trainW, trainH);
        lastX = x;
    }

    public void paintComponent1(Graphics gg) {

        int w1 = getWidth()+50;
        int h1 = getHeight()+50;
        int trainW1 = 100;
        int trainH1 = 10;
        int trainSpeed1 = 10;
        int x1 = lastX1 + trainSpeed1;

        // Train train0=new Train(100, 50, 100, 10, 6, 9);

        Graphics2D gg1 = (Graphics2D) gg;
        if (x1 > w1 + trainW1) {
            x1 = -trainW1-30;

        }
        gg1.setColor(Color.RED);
        gg1.fillRect(x1-30, h1/2 + trainH1, trainW1, trainH1);
        lastX1= x1;
    }

    public void paintComponent2(Graphics ggg) {

        int w2 = getWidth()+50;
        int h2 = getHeight()+50;
        int trainW2 = 200;
        int trainH2 = 35;
        int trainSpeed2 = 2;
        int x2 = lastX2 + trainSpeed2;

        // Train train0=new Train(100, 50, 100, 10, 6, 9);

        Graphics2D gg = (Graphics2D) ggg;
        if (x2 > w2 + trainW2) {
            x2 = -trainW2;

        }
        gg.setColor(Color.GREEN);
        gg.fillRect(x2-30, h2/2 + trainH2, trainW2, trainH2);
        lastX2= x2;
    }
}
