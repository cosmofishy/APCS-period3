
public class Train{
    private int w;
    private int h;
    private int trainW;
    private int trainH;
    private int trainSpeed;
    private int x;
    public Train()

    {
        // initialise instance variables

        w = 0;
        h =0;
        trainW=0;
        trainH=0;
        trainSpeed=0;
        x=0;
    }

    public Train(int w, int h, int trainW,int trainH, int trainSpeed, int x ) {
        Train train1 = new Train(100, 50, 100, 10, 6, x);
    }

    public int getW(){
        return w;
    }

    public int getH(){
        return h;
    }

    public int getTrainW(){
        return trainW;
    }

    public int getTrainH(){
        return trainH;
    }

    public int getTrainSpeed(){
        return trainSpeed;
    }

    public int getX(){
        return x;
    }

}
