import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.util.ArrayList;
import java.util.List;

import javax.swing.AbstractAction;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;
import javax.swing.Timer;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import javax.swing.JFrame;
import java.awt.Color;
import java.awt.Graphics;
import javax.swing.JComponent;
import javax.swing.*;
import java.awt.*;
import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.event.*;
import javax.swing.*;
public class Rebound extends JFrame implements KeyListener {
    /* Milliseconds between each time balls move */
    static final int MOVE_DELAY = 20;

    private mainDraw draw;
private mainFrame frame;
    public void keyPressed(KeyEvent e) {
        System.out.println("keyPressed");
    }

    public void keyReleased(KeyEvent e) {
        if(e.getKeyCode()== KeyEvent.VK_RIGHT)
            draw.moveRight();
        else if(e.getKeyCode()== KeyEvent.VK_LEFT)
            draw.moveLeft();
        else if(e.getKeyCode()== KeyEvent.VK_DOWN)
            draw.moveDown();
        else if(e.getKeyCode()== KeyEvent.VK_UP)
            draw.moveUp();
        //ballContainer.addBall();
    }

    public void keyTyped(KeyEvent e) {
        System.out.println("keyTyped");
    }
    JButton addBallButton = new JButton(new AbstractAction("Add ball") {
                public void actionPerformed(ActionEvent e) {
                    ballContainer.addBall();
                }
            });

    /* The Panel for holding the balls. It will need to
     * keep tracks of each ball, so we'll make it a subclass
     * of JPanel with extra code for the ball management (see
     * the definition, after the end of the Rebound class) */
    BallPanel ballContainer = new BallPanel();

    public Rebound() {

        super("Rebound");
        this.draw=new mainDraw();
        addKeyListener(this);
        setFocusable(true);
        setFocusTraversalKeysEnabled(false);
        setDefaultCloseOperation (JFrame.EXIT_ON_CLOSE);
        getContentPane().setLayout(new BoxLayout(getContentPane(), BoxLayout.X_AXIS));

        /* There was no neat way to specify the button size
         * when we declared it, so let's do that now */
        addBallButton.setPreferredSize(new Dimension(400, 35));

        /* Add the components to this window */
        getContentPane().add(addBallButton);
        getContentPane().add(ballContainer);
        getContentPane().add(draw);
        pack();
        /* Create a timer that will send an ActionEvent
         * to our BallPanel every MOVE_DELAY milliseconds */
        new Timer(MOVE_DELAY, ballContainer).start();
    }

    /* The entry point for our program */
    public static void main(String[] args) {
        /* We use this utility to ensure that code
         * relating to Swing components is executed
         * on the correct thread (the Swing event 
         * dispatcher thread) */
        SwingUtilities.invokeLater(new Runnable() {
                public void run() {
                    new Rebound().setVisible(true);
                    //new MainDraw().setVisable(true);
                }
            });
    }

 
}

