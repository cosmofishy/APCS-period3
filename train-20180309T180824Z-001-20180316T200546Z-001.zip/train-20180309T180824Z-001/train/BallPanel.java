import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.util.ArrayList;
import java.util.List;

import javax.swing.AbstractAction;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;
import javax.swing.Timer;

/* Our subclass of JPanel that also manages a list of
 * balls. It implements ActionListener so that it can
 * act on the Timer event we set up in the Rebound class */
class BallPanel extends JPanel implements ActionListener {
    /* An automatically expanding list structure that can
     * contain 0 or more Ball objects. We'll create a Ball
     * class to manage the position, movement and draw code
     * for each ball. */
    List<Ball> balls = new ArrayList<Ball>();
    /* Let's add some code that will be run
     * when the panel is resized (which will happen
     * if its window is resized.) We need to make sure
     * that each Ball is told about the new bounds
     * of the component, so it knows that the place
     * where it should bounce has changed */
    public BallPanel() {
        super();
        setPreferredSize(new Dimension(400,300));
        addComponentListener(new ComponentAdapter() {
            public void componentResized(ComponentEvent e) {
                if (BallPanel.this == e.getComponent()) {
                    for (Ball ball : balls) {
                        ball.setBounds(getWidth(), getHeight());
                    }
                }
            }
        });
    }

    /* This method is part of the JPanel class we are subclassing.
     * Here we change the implementation of the method, ensuring
     * we call the original implementation so that we are only
     * adding to what it does. */
    public void paintComponent(Graphics g) {
        /* Call the original implementation of this method */
        super.paintComponent(g);

        /* Lets draw a black border around the bounds of the component
         * to make it clear where the balls should rebound from */
        g.drawRect(0,0,getWidth(),getHeight());

        /* Now lets draw all the balls we currently have stored in
         * our list. */
        for (Ball ball : balls) {
            ball.draw(g);
        }
    }
    /* This method will add a new Ball into our list. Remember
     * from earlier that we call this when our button is clicked. */
    public void addBall() { 
        balls.add(new Ball(this,10,15,getWidth(),getHeight())); 
    }
    /* This method will receive the event from Timer we set up in
     * the Rebound class. We want it to cause all the ball to
     * move to their next position. */
    public void actionPerformed(ActionEvent e) {
        for(Ball ball : balls) {
            ball.move();
        }
        /* Request that Swing repaints this JPanel. This should
         * cause the paintComponent() method we implemented
         * above to be called soon after. */
        repaint();
    }
}